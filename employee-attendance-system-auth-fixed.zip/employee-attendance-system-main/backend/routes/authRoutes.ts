import { Router, Request, Response } from 'express';
import { randomUUID } from 'crypto';
import { db } from '../db';
import { Employee } from '../../src/types';

export const authRouter = Router();

const sessions = new Map<string, string>();
export function getSessionUserId(token: string | undefined): string | null {
  if (!token) return null;
  return sessions.get(token) || null;
}

// Login
authRouter.post('/login', (req: Request, res: Response) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  const employee = db.employees.find(e => e.email.toLowerCase() === email.toLowerCase());
  if (!employee) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  if (!employee.password || employee.password !== password) {
    return res.status(401).json({ error: 'Invalid email or password' });
  }

  const { password: _, ...safeUser } = employee;
  const token = `session-${randomUUID()}`;
  sessions.set(token, employee.id);
  return res.json({ token, user: safeUser });
});


// Logout / revoke current session
export function revokeSession(token: string | undefined): void {
  if (token) sessions.delete(token);
}

authRouter.post('/logout', (req: Request, res: Response) => {
  const header = req.header('authorization');
  const token = header?.startsWith('Bearer ') ? header.slice(7) : undefined;
  revokeSession(token);
  return res.json({ message: 'Logged out successfully' });
});

// Register
authRouter.post('/register', (req: Request, res: Response) => {
  const { name, email, password, department, designation, employeeId, phone } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email and password are required' });
  }
  if (String(password).length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters' });
  }

  const existing = db.employees.find(e => e.email.toLowerCase() === email.toLowerCase());
  if (existing) {
    return res.status(409).json({ error: 'Employee with this email already exists' });
  }

  const newEmp: Employee = {
    id: employeeId || `IEC-${Math.floor(100 + Math.random() * 900)}`,
    name,
    email,
    password,
    role: 'employee',
    department: department || 'Engineering',
    designation: designation || 'Associate Consultant',
    shiftStart: '09:00',
    shiftEnd: '18:00',
    joiningDate: new Date().toISOString().split('T')[0],
    leaveBalance: {
      casualLeave: 12.0,
      sickLeave: 8.0,
      privilegeLeave: 15.0,
      lossOfPayDays: 0,
    },
    phone: phone || '+91 98000 00000',
  };

  db.employees.push(newEmp);
  const { password: _, ...safeUser } = newEmp;
  const token = `session-${randomUUID()}`;
  sessions.set(token, newEmp.id);
  return res.status(201).json({ token, user: safeUser });
});
