import express, { Express, Request, Response } from 'express';
import { db } from './db';
import { authRouter } from './routes/authRoutes';
import { employeeRouter } from './routes/employeeRoutes';
import { attendanceRouter } from './routes/attendanceRoutes';
import { leaveRouter } from './routes/leaveRoutes';
import { regularizationRouter } from './routes/regularizationRoutes';
import { deductionRouter } from './routes/deductionRoutes';
import { getSessionUserId } from './routes/authRoutes';

export function createBackendApp(): Express {
  const app = express();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Service Health Endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'Inner Eye Attendance Backend API',
      timestamp: new Date().toISOString(),
    });
  });

  // Require an authenticated session for all application APIs except health/auth.
  app.use('/api', (req: Request, res: Response, next) => {
    if (req.path === '/health' || req.path.startsWith('/auth/')) return next();
    const header = req.header('authorization');
    const token = header?.startsWith('Bearer ') ? header.slice(7) : undefined;
    const userId = getSessionUserId(token);
    if (!userId) return res.status(401).json({ error: 'Authentication required' });
    (req as Request & { userId?: string }).userId = userId;
    next();
  });

  // Reset Endpoint for Evaluation Dataset (authenticated only)
  app.post('/api/reset', (req: Request, res: Response) => {
    const user = db.employees.find(e => e.id === (req as Request & { userId?: string }).userId);
    if (user?.role !== 'hr_admin') return res.status(403).json({ error: 'HR administrator access required' });
    db.reset();
    return res.json({ message: 'System database restored to benchmark seed dataset' });
  });

  // Mount Modular Routes
  app.use('/api/auth', authRouter);
  app.use('/api/employees', employeeRouter);
  app.use('/api/attendance', attendanceRouter);
  app.use('/api/leaves', leaveRouter);
  app.use('/api/regularizations', regularizationRouter);
  app.use('/api/deductions', deductionRouter);

  return app;
}
