import React from 'react';
import { X, Lock, Mail, User, Briefcase, Building } from 'lucide-react';
import { Employee, Department } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (email: string, password: string) => Promise<boolean>;
  onRegister: (newEmp: Employee) => Promise<boolean>;
  allowClose?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onLogin,
  onRegister,
  allowClose = true,
}) => {
  const [tab, setTab] = React.useState<'login' | 'register'>('login');
  const [loginEmail, setLoginEmail] = React.useState('');
  const [loginPassword, setLoginPassword] = React.useState('');
  const [loginError, setLoginError] = React.useState('');
  const [loginLoading, setLoginLoading] = React.useState(false);

  const [regName, setRegName] = React.useState('');
  const [regEmail, setRegEmail] = React.useState('');
  const [regPassword, setRegPassword] = React.useState('');
  const [regDept, setRegDept] = React.useState<Department>('Engineering');
  const [regDesignation, setRegDesignation] = React.useState('');
  const [regEmpId, setRegEmpId] = React.useState('');
  const [regError, setRegError] = React.useState('');
  const [regLoading, setRegLoading] = React.useState(false);

  React.useEffect(() => {
    if (!isOpen) return;
    setLoginError('');
    setRegError('');
  }, [isOpen]);

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoginLoading(true);
    try {
      const success = await onLogin(loginEmail.trim(), loginPassword);
      if (success) onClose();
      else setLoginError('Invalid email or password.');
    } catch (error) {
      setLoginError(error instanceof Error ? error.message : 'Unable to sign in. Please try again.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regName.trim() || !regEmail.trim() || !regPassword.trim()) {
      setRegError('Please complete all required fields.');
      return;
    }
    if (regPassword.length < 8) {
      setRegError('Password must be at least 8 characters.');
      return;
    }

    const newEmp: Employee = {
      id: regEmpId.trim() || `IEC-${Date.now().toString().slice(-6)}`,
      name: regName.trim(),
      email: regEmail.trim(),
      password: regPassword,
      role: 'employee',
      department: regDept,
      designation: regDesignation.trim() || 'Consultant',
      shiftStart: '09:00',
      shiftEnd: '18:00',
      joiningDate: new Date().toISOString().split('T')[0],
      leaveBalance: {
        casualLeave: 12.0,
        sickLeave: 8.0,
        privilegeLeave: 15.0,
        lossOfPayDays: 0,
      },
      phone: '+91 98000 00000',
    };

    setRegLoading(true);
    try {
      const success = await onRegister(newEmp);
      if (success) onClose();
    } catch (error) {
      setRegError(error instanceof Error ? error.message : 'Unable to register. Please try again.');
    } finally {
      setRegLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-100 text-slate-800 animate-in fade-in zoom-in duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Inner Eye Consultancy Services Portal</h3>
            <p className="text-[11px] text-slate-500">Employee Authentication & Registration</p>
          </div>
          {allowClose && (
            <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100" aria-label="Close">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="flex rounded-xl bg-slate-100 p-1 my-4 text-xs font-semibold">
          <button type="button" onClick={() => setTab('login')} className={`flex-1 py-1.5 rounded-lg transition-all ${tab === 'login' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}>Employee Login</button>
          <button type="button" onClick={() => setTab('register')} className={`flex-1 py-1.5 rounded-lg transition-all ${tab === 'register' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'}`}>Register New Staff</button>
        </div>

        {tab === 'login' ? (
          <form onSubmit={handleLoginSubmit} className="space-y-3.5 text-xs">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Work Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="name@innereye.com" required autoComplete="username" />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Enter your password" required autoComplete="current-password" />
              </div>
            </div>
            {loginError && <p className="text-rose-600 text-xs font-medium">{loginError}</p>}
            <button disabled={loginLoading} type="submit" className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:cursor-not-allowed">
              {loginLoading ? 'Signing in…' : 'Sign In to Portal'}
            </button>
            <p className="text-[11px] text-slate-400 text-center pt-1">Use your registered work email and password. Demo one-click account switching has been disabled.</p>
          </form>
        ) : (
          <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs max-h-[65vh] overflow-y-auto pr-1">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
                <div className="relative"><User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" /><input type="text" value={regName} onChange={(e) => setRegName(e.target.value)} placeholder="e.g. Rohit Mehra" className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500" required /></div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Employee ID <span className="font-normal text-slate-400">(optional)</span></label>
                <input type="text" value={regEmpId} onChange={(e) => setRegEmpId(e.target.value)} placeholder="Auto-generated" className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 font-mono" />
              </div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Email</label>
              <div className="relative"><Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" /><input type="email" value={regEmail} onChange={(e) => setRegEmail(e.target.value)} placeholder="rohit@innereye.com" className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500" required /></div>
            </div>
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative"><Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" /><input type="password" value={regPassword} onChange={(e) => setRegPassword(e.target.value)} placeholder="At least 8 characters" className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500" required minLength={8} autoComplete="new-password" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Department</label>
                <div className="relative"><Building className="w-4 h-4 text-slate-400 absolute left-3 top-2.5 pointer-events-none" /><select value={regDept} onChange={(e) => setRegDept(e.target.value as Department)} className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg bg-white focus:ring-2 focus:ring-blue-500"><option>Engineering</option><option>Design</option><option>Product</option><option>Human Resources</option><option>Marketing</option><option>Operations</option><option>Finance</option></select></div>
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Designation</label>
                <div className="relative"><Briefcase className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" /><input type="text" value={regDesignation} onChange={(e) => setRegDesignation(e.target.value)} placeholder="Associate Consultant" className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500" /></div>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-blue-50 border border-blue-100 text-blue-800 text-[11px]">New self-registered accounts are created as <strong>Standard Employee</strong>. HR Administrator access can only be assigned by an authorized administrator.</div>
            {regError && <p className="text-rose-600 text-xs font-medium">{regError}</p>}
            <button disabled={regLoading} type="submit" className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer disabled:cursor-not-allowed">{regLoading ? 'Creating account…' : 'Complete Registration'}</button>
          </form>
        )}
      </div>
    </div>
  );
};
